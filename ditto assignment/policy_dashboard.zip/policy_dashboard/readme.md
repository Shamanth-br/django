# Policy dashboard

1. Install Django
pip install django

2. Navigate to Your Project Directory:
cd path_to_your_project

3. Run Migrations:
python manage.py makemigrations
python manage.py migrate

4. Starting the Development Server
python manage.py runserver

5. Access Your Project:
http://localhost:8000/admin


### Additional Notes

- I have added all the functionality in the admin dashboard.
- For the level 2  problem i.e sending mail, I have removed my gmail app password from settings since it is sensitive data. Please know the mail functionaly does work.
- I have included 'ICICI Life', 'Max Life', and 'HDFC Life' policies as fields in the 'Policy' model to streamline our database due to minimal differences in required fields. Ideally, dynamic validation using JavaScript would be implemented to hide non-required fields, but Django does not support this feature. 
- I've introduced the 'AdminComment' model, where the email field serves as a foreign key for managing admin comments.

