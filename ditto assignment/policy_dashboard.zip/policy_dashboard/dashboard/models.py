from django.db import models
from django.core.validators import RegexValidator,MinValueValidator,MaxValueValidator
from django.core.exceptions import ValidationError
from  random import randrange

class Policy(models.Model):

#varialbles 
    POLICY_CHOICES = [
        ('ICICI_Life','ICICI Life'),
        ('Max_Life','Max Life'),
        ('HDFC_Life','HDFC Life')
    ]

    POLICY_STATUS_CHOICES = [
        ('requirements_awaited', 'Requirements Awaited'),
        ('requirements_closed', 'Requirements Closed'),
        ('underwriting', 'Underwriting'),
        ('policy_issued', 'Policy Issued'),
        ('policy_rejected', 'Policy Rejected'),
    ]
    MEDICAL_TYPE_CHOICES = [
        ('tele_medicals', 'Tele Medicals'),
        ('physical_medicals', 'Physical Medicals'),
    ]
    MEDICAL_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('scheduled', 'Scheduled'),
        ('waiting_for_report', 'Waiting for Report'),
        ('done', 'Done'),
    ]
     
    #Fields used: ('policy_name','customer_name','email','phone_number','date_of_birth','policy_cover','policy_status','medical_type','medical_status','remarks')
    policy_number = models.CharField(max_length=15,editable=False,null=True)
    policy_name = models.CharField(max_length=30,choices=POLICY_CHOICES,blank=False,null=True)
    application_number = models.CharField(max_length=10, unique=True, editable=False,null=True)
    customer_name = models.CharField(max_length=100,null=True,blank=False)
    email = models.EmailField(null=True,blank=False,unique=True)

    #phone_regex = RegexValidator(regex=r'^\+?91?\d{10}$', message="Phone number must be entered in the format: '+919999999999'.") ,validators=[phone_regex]
    phone_number = models.CharField(null=True, max_length=13, help_text='Enter valid Indian phone number')

    date_of_birth = models.DateField(null=True)
    policy_cover = models.BigIntegerField(null=True,validators=[MinValueValidator(2500000), MaxValueValidator(50000000)])
    policy_status = models.CharField(max_length=30,choices=POLICY_STATUS_CHOICES,null=True)
    medical_type = models.CharField(max_length=50,blank=True,choices=MEDICAL_TYPE_CHOICES,null=True)
    medical_status = models.CharField(max_length=50,blank=True,choices=MEDICAL_STATUS_CHOICES, null=True)
    remarks = models.TextField(null=True,blank=True, )
    created_date = models.DateTimeField(auto_now_add=True)
    
    def save(self, *args, **kwargs):
        if not self.application_number:
            self.application_number = randrange(1000000000,9999999999)

        # To generate policy number if policy status is 'policy issued'
        if self.policy_status == 'policy_issued' and not self.policy_number:
            self.policy_number = randrange(1000000000,9999999999)
        else:
            self.policy_number = None
        super().save(*args, **kwargs)

    def __str__(self):
        return self.email
    

# Model for storing admin comment
class AdminComment(models.Model):
    email = models.ForeignKey(Policy,related_name='comments',on_delete=models.CASCADE,null=True)
    comment = models.TextField(null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Comment on {self.email} - {self.comment}"
    


    



