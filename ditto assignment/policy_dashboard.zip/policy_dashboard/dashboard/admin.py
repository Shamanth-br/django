from django.contrib import admin
from .models import Policy,AdminComment
from .forms import PolicyForm


@admin.register(Policy)
class PolicyAdmin(admin.ModelAdmin):
    form = PolicyForm
    list_display = [field.name for field in Policy._meta.fields][0:len(Policy._meta.fields)-1]
    search_fields = ('application_number', 'customer_name', 'email', 'phone_number')
    list_filter = ('policy_status', 'customer_name', 'created_date')
    list_editable = ('policy_name','customer_name','email','phone_number','date_of_birth',
                    'policy_status','medical_type','medical_status','remarks')
    ordering = ('-created_date',)

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)    
        return form
    

@admin.register(AdminComment)
class AdminCommentAdmin(admin.ModelAdmin):
    list_display = [field.name for field in AdminComment._meta.fields]
    list_per_page = 20
    search_fields = ['email__email']

    def get_search_results(self, request, queryset, search_term):
        queryset, use_distinct = super().get_search_results(request, queryset, search_term)

        # Customize queryset to filter by email using related model's field
        try:
            search_term_as_int = int(search_term)
            queryset |= self.model.objects.filter(email__email__icontains=search_term_as_int)
        except ValueError:
            queryset |= self.model.objects.filter(email__email__icontains=search_term)

        return queryset, use_distinct
    
    

    
    
    