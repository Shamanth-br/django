from django import forms
from .models import Policy
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _
from datetime import date


class PolicyForm(forms.ModelForm):
    class Meta:
        model = Policy
        fields = '__all__'
    class Media:
        js = ('js/admin_policy.js',)
        css = {
            'all': ('css/admin_policy.css',),
        }
        

    # custome validation for accepting age i.e age >18 and age <99
    def clean_date_of_birth(self):
        date_of_birth = self.cleaned_data.get('date_of_birth')
        today = date.today()
        age = today.year - date_of_birth.year - ((today.month, today.day) < (date_of_birth.month, date_of_birth.day))
        if age < 18 or age > 99:
            raise ValidationError(_('Age must be between 18 and 99 years.'))
        return date_of_birth
    
    