from .models import Policy
from django.core.mail import send_mail
from django.dispatch import receiver
from django.db.models.signals import post_save
from django.conf import settings
from . import signals


# Method for sending mail when policy status is 'issued'
def send_policy_issued_email(customer_email,policy_name, policy_details):
    subject = f'Your  {policy_name} Policy Has Been Issued'
    message = f'Dear Customer,\n\nYour policy has been issued. Here are the details:\n\n{policy_details}\n\nThank you for choosing us.'
    email_from = settings.EMAIL_HOST_USER
    recipient_list = [customer_email]
    send_mail(subject, message, email_from, recipient_list)

@receiver(post_save, sender=Policy)
def send_policy_issued_email_signal(sender, instance, created, **kwargs):
    if created and instance.policy_status == 'policy_issued':  # Only send email when a new policy is created
        policy_details = f'Policy Type: {instance.policy_name} \nPolicy Number: {instance.policy_number}'
        send_policy_issued_email(instance.email, instance.policy_name,policy_details)
        
    