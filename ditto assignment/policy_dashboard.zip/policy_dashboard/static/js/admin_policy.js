document.addEventListener('DOMContentLoaded', function() {
    const policyTypeField = document.getElementById('id_policy_name');
    const medicalTypeField = document.getElementById('id_medical_type').closest('.form-row');
    const medicalStatusField = document.getElementById('id_medical_status').closest('.form-row');
    const remarksField = document.getElementById('id_remarks').closest('.form-row');

    function toggleMedicalFields() {
        if (policyTypeField.value === 'ICICI_Life') {
            medicalTypeField.style.display = 'none';
            medicalStatusField.style.display = 'none';
        } else {
            medicalTypeField.style.display = '';
            medicalStatusField.style.display = '';
        }
    }

    function toggleRemarksFields() {
        if (policyTypeField.value === 'Max_Life') {
            remarksField.style.display = 'none';
        } else {
            remarksField.style.display = '';
        }
    }

    
    // Initial check
    toggleMedicalFields();
    toggleRemarksFields();

    // Listen for changes in the policy type field
    policyTypeField.addEventListener('change', toggleMedicalFields);
    policyTypeField.addEventListener('change', toggleRemarksFields);
});

